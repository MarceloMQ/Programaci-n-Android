package com.mmadariaga.evaluacionu1;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    BtnConfirmar

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BtnConfirmar=(Button) findViewById(R.id.BtnConfirmar);
        Nombre1=(EditText) findViewById(R.id.Nombre1);
        BtnConfirmar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),Nombre1.getText().toString()+ ", Pedido confirmado!",Toast.LENGTH_LONG).show();
            }
        });


    }
}